import React, { Component } from "react";
import { withStyles } from "@mui/styles";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableSortLabel,
  Paper,
} from "@mui/material";
import "./resizableTable.css";

const styles = (theme) => ({
  open: {},
  close: {},
  allSelect: {},
  myAlarm: {},
});

class ResizableTable extends Component {
  constructor(props) {
    super(props);
    this.tabSelector = "#resize_table";

    this.state = {
      data: props.data,
    };
  }

  componentDidMount() {
    // $("#resize_table").colResizable({
    //   disable: true,
    // });
    // // page resize
    // $("#resize_table").colResizable({
    //   fixed: false,
    //   liveDrag: true,
    // });
  }

  componentDidUpdate() {
    let self = this;

    // $("#resize_table").colResizable({
    //   disable: true,
    // });

    // // page resize
    // $("#resize_table").colResizable({
    //   fixed: false,
    //   liveDrag: true,
    // });
  }

  onItemDoubleClick(item, index) {
    if (this.props.onItemDoubleClick) {
      this.props.onItemDoubleClick(item, index);
    }
  }

  onItemClick(item, index) {
    if (this.props.onItemClick) {
      this.props.onItemClick(item, index);
    }
  }

  render() {
    const { head, rows } = this.props;

    return (
      <Paper className="tb_area">
        <div className="body_content">
          <div className={`alarmList`}>
            <div className="wrap_table_info">
              <div className="table_cont">
                <Table
                  className={`alarmListTable`}
                  size={"medium"}
                  id="resize_table"
                >
                  <TableHead>
                    <TableRow>
                      {head.map((item, index) => {
                        return (
                          <TableCell id={"head_" + index} key={item.id}>
                            <TableSortLabel>{item.label}</TableSortLabel>
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    {rows.map((row, index) => {
                      return (
                        <TableRow
                          hover
                          onDoubleClick={() =>
                            this.onItemDoubleClick(row, index)
                          }
                          onClick={() => this.onItemClick(row, index)}
                          tabIndex={-1}
                          key={index}
                        >
                          {head.map((item, index) => {
                            <TableCell
                              key={index}
                              component="td"
                              scope="row"
                              padding="none"
                              title={row[item.id]}
                            >
                              {row[item.id]}
                            </TableCell>;
                          })}
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
                {/* </ScrollBars> */}
              </div>
            </div>
            {/* [E] 게시판 테이블 */}
          </div>
        </div>
      </Paper>
    );
  }
}

export default withStyles(styles)(ResizableTable);
