import React from "react";
import "./testTable.css";
import ResizableTable from "../../components/resizableTable/ResizableTable";

const head = [
  {
    id: "occurred",
    width: "154px",
    numeric: true,
    disablePadding: true,
    label: "alarm_occurred",
    customCell: false,
  },
  {
    id: "alarmSeq",
    width: "86px",
    numeric: true,
    disablePadding: true,
    label: "alarm_alarm_id",
    customCell: false,
  },
  {
    id: "alarmRuleName",
    width: "258px",
    numeric: true,
    disablePadding: true,
    label: "alarm_alarm_name",
    customCell: false,
  },
  {
    id: "alarmgradeCode",
    width: "85px",
    numeric: true,
    disablePadding: true,
    label: "alarm_risk_level",
    customCell: '<span class="state_risk ${param}"><em>${param}</em></span>',
    customCellParam: ["alarmgradeCode", "alarmgradeCode"],
  },
  {
    id: "tenantNm",
    width: "120px",
    numeric: true,
    disablePadding: true,
    label: "alarm_tenant",
    customCell: false,
  },
  {
    id: "dmnNm",
    width: "102px",
    numeric: true,
    disablePadding: true,
    label: "alarm_domain",
    customCell: false,
  },
  {
    id: "statusNm",
    width: "154px",
    numeric: true,
    disablePadding: true,
    label: "alarm_status",
    customCell: false,
  },
  {
    id: "assignee",
    width: "136px",
    numeric: true,
    disablePadding: true,
    label: "alarm_assignee",
    customCell: false,
  },
  {
    id: "location",
    width: "182px",
    numeric: true,
    disablePadding: true,
    label: "alarm_location",
    customCell: "${param} / ${param} ",
    customCellParam: ["tenantNm", "dmnNm"],
  },
  {
    id: "pbSeq",
    width: "102px",
    numeric: true,
    disablePadding: true,
    label: "alarm_playBook",
    customCell: false,
  },
];

function _createData(
  time,
  alarmId,
  alarmName,
  tenant,
  domain,
  status,
  category,
  riskLevel,
  assignee,
  location,
  assetId,
  assetName,
  eMap,
  playBook
) {
  return {
    id: alarmId,
    time,
    alarmId,
    alarmName,
    tenant,
    domain,
    status,
    category,
    riskLevel,
    assignee,
    location,
    assetId,
    assetName,
    eMap,
    playBook,
  };
}
const rows = [
  _createData(
    "2019/01/16 15:30:19",
    "218941",
    "[single]ALARM_SECURITY_DOS_Icmp",
    `SKinfosec2`,
    "이지세이버",
    "신규(미승인)",
    "VMS11",
    "P1",
    "-",
    "Skinfosec2/이지세이버/이지세이버",
    "EZ_Restroo",
    "EZ_Restroo1",
    "보기",
    "-"
  ),
  _createData(
    "2019/01/16 15:30:18",
    "218942",
    "[single]ALARM_SECURITY_DOS_Icmp",
    `SKinfosec2`,
    "이지세이버",
    "신규(미승인)",
    "VMS11",
    "P2",
    "-",
    "Skinfosec2/이지세이버/이지세이버",
    "EZ_Restroo",
    "EZ_Restroo1",
    "보기",
    "-"
  ),
];

export default function TestTable() {
  return (
    <div className="testTable">
      <ResizableTable head={head} rows={rows} />
    </div>
  );
}
