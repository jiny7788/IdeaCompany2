import React from "react";
import "./productList.css";
import { DataGridPro } from "@mui/x-data-grid-pro";
import { DeleteOutline } from "@mui/icons-material";
import { productRows } from "../../dummyData";
import { Link } from "react-router-dom";
import { useState } from "react";

export default function ProductList() {
  const columns = [
    { field: "id", headerName: "ID", width: 70 },
    {
      field: "name",
      headerName: "Product",
      resizable: true,
    },
    { field: "stock", headerName: "Stock", resizable: true },
    { field: "status", headerName: "Status", resizable: true },
    { field: "price", headerName: "Price", resizable: true },
    {
      field: "action",
      headerName: "Action",

      renderCell: (params) => {
        return (
          <>
            <Link to={"/product/" + params.row.id}>
              <button className="productListEdit">Edit</button>
            </Link>
            <DeleteOutline
              className="productListDelete"
              onClick={() => handleDelete(params.row.id)}
            />
          </>
        );
      },
      resizable: true,
    },
  ];

  const [data, setData] = useState(productRows);
  const handleDelete = (id) => {
    setData(data.filter((item) => item.id !== id));
  };
  return (
    <div className="productList">
      <DataGridPro
        rows={data}
        disableSelectionOnClick
        columns={columns}
        pageSize={10}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </div>
  );
}
