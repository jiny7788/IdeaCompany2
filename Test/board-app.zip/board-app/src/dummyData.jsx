export const userData = [
  {
    name: "Jan",
    "Active User": 4490,
  },
  {
    name: "Feb",
    "Active User": 3430,
  },
  {
    name: "Mar",
    "Active User": 2490,
  },
  {
    name: "Apr",
    "Active User": 3390,
  },
  {
    name: "May",
    "Active User": 1230,
  },
  {
    name: "Jun",
    "Active User": 5290,
  },
  {
    name: "Jul",
    "Active User": 2390,
  },
  {
    name: "Aug",
    "Active User": 4540,
  },
  {
    name: "Sep",
    "Active User": 4235,
  },
  {
    name: "Oct",
    "Active User": 4490,
  },
  {
    name: "Nov",
    "Active User": 4500,
  },
  {
    name: "Dec",
    "Active User": 4600,
  },
];

export const userRows = [
  {
    id: 1,
    username: "Snow1",
    avatar: "/logo192.png",
    email: "kevin1@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 2,
    username: "Snow2",
    avatar: "/logo192.png",
    email: "kevin2@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 3,
    username: "Snow3",
    avatar: "/logo192.png",
    email: "kevin3@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 4,
    username: "Snow4",
    avatar: "/logo192.png",
    email: "kevin4@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 5,
    username: "Snow5",
    avatar: "/logo192.png",
    email: "kevin5@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 6,
    username: "Snow6",
    avatar: "/logo192.png",
    email: "kevin6@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 7,
    username: "Snow7",
    avatar: "/logo192.png",
    email: "kevin7@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 8,
    username: "Snow8",
    avatar: "/logo192.png",
    email: "kevin8@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
  {
    id: 9,
    username: "Snow9",
    avatar: "/logo192.png",
    email: "kevin9@gmail.com",
    status: "active",
    transaction: "$120.00",
  },
];

export const productRows = [
  {
    id: 1,
    name: "Apple Watch",
    img: "/logo192.png",
    stock: 23,
    status: "active",
    price: "$120.00",
  },
  {
    id: 2,
    name: "Apple Macbook",
    img: "/logo192.png",
    stock: 12,
    status: "active",
    price: "$120.00",
  },
  {
    id: 3,
    name: "SnApple Airpods",
    img: "/logo192.png",
    stock: 6,
    status: "active",
    price: "$120.00",
  },
];

export const productData = [
  {
    name: "Jan",
    Sales: 4490,
  },
  {
    name: "Feb",
    Sales: 3430,
  },
  {
    name: "Mar",
    Sales: 2490,
  },
];
