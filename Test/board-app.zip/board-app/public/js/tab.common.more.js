/*
 * 파일명:		tab.common.more.js
 * 설  명 :		alarm 탭 과 동일하지만 공통 사용되는 부분으로 추가작업함
 * 작성자:		glim
 * 최초작성일:	2018/03/14
 * 최종수정일:	2018/03/14
 * Comment
 * 탭관련되어 임시 로직들 
 * 개발에 맞추어 작업하시면 될것같습니다.
 * funcTabComMoreOnOff 는 기존 함수와 동일한 로직입니다. 
 * tab-link 탭링크에  href="#탭컨텐츠이름" 으로 사용하시고 페이지 주석부분 해제시 동일하게 동작가능
*/
 
//$(window).on("load", function (e) {
$(document).ready( function(){
 	
	//Tab More 실행
	if ( $('.tab-com-more').length > 0 ){
		funcTabComMoreReset('.tab-com-more');
	}
	
});

/*
 * date : 20180314
 * last : 20180314
 * name : funcTabComMoreReset( 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭이 14개 이상 일 경우 더보기 버튼 생성 (14 이상은 보이지 않음)
   -. 삭제/추가시 탭 변동시 무조건 호출필요
   -. 기존 ul 에 추가되며 14개보다 많아질경우 더보기 버튼/목록 생성되고 
   -. 많아질경우 기존 ul 은 나두고 더보기 컨테이너에 컨텐츠 추가함
 */
function funcTabComMoreReset (container){
	//console.log ("funcTabComMoreReset");
	var viewTabLen = 12;
	var btnMoreWidth = 34;
	var container = $(container);
	var btnMore = container.find('.tab-more');
	var tabMoreListContainer = container.find(".tab-more-list-wrap")
	var tabMoreListUl = container.find(".tab-more-list-ul")
	var tabitem = $('> .tabs', container).find('.tab-item');
	var tabitemMore = $('.tabs', container).find('.tab-item:gt('+(viewTabLen-1)+')');//더보기로 clone 시킬 item
	var viewWidth = container.width() - btnMoreWidth;
	tabitem.css('width', viewWidth/viewTabLen);
	tabMoreListContainer.hide();
		
	if (tabitem.length > viewTabLen) {//14개보다 많을 때
		btnMore.show();
		
		tabMoreListUl.empty();
		tabitemMore.each(function(n) {
			tabMoreListUl.append($(this).removeAttr('style').clone());
		});
		
	}else{
		btnMore.hide();
	}
}

/*
 * date : 20180314
 * last : 20180314
 * name : funcTabComMoreListOnOff( 클릭타겟, 컨테이너 )
 * pram :  el (target) / container(parent) / tg (target ele selector)
 * Desc : 탭 더보기 영역 onoff
 */
function funcTabComMoreListOnOff (el, container, tg){
	var _container = $(container);
	var _tg = $(tg);
	
	if ( _container.find( tg+":visible").length > 0 ){//감춰라
		$(_tg).hide();
	}else{//보여줘라
		$(_tg).show();
	}
}


/*
 * date : 20180314
 * last : 20180314
 * name : funcTabComMoreOnOff( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 On/off 탭 활성화
 */
function funcTabComMoreOnOff (el, container, callback) {
	 	
	var tabitem = $(container).find(el).parents('.tab-item');
	//var tg = $($(tabitem).find('.tab-link').attr("href"));//target container - 탭링크 컨텐츠 주석
	if ( $(tabitem).hasClass ("on") ){//클릭된타겟 활성화일경우 return
		return false;
	}
	//off
	var oldTabitem = $(container).find('.tab-item.on');
	if ( oldTabitem.length > 0 ){
		//기존 활성화탭 off
		$(oldTabitem).removeClass('on');
		//$($(oldTabitem).find('.tab-link').attr("href")).hide();//- 탭링크 컨텐츠 주석
	}
	
	//on
	tabitem.addClass('on');//tab active
	
	/* $(tg).show(0, function(){//tab show - 탭링크 컨텐츠 주석
		if ( callback != null && typeof callback === "function" ){
			callback.apply ( null, []);
		}
	}); */
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}


/*
 * date : 20180314
 * last : 20180314
 * name : funcTabComMoreDelete( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 삭제 (morelist 에 나오는 탭 경우 2개임)
 */
function funcTabComMoreDelete (el, container, callback) {
	var tabcontainer = $(container);
	var tabitem = $(container).find(el).parents('.tab-item');
	var delidx = $(tabitem).data('idx');//delete idx
	
	var delTab = tabcontainer.find("[data-idx='" + delidx + "']");
	tabcontainer.find(delTab).remove();
	
	//reset
	funcTabComMoreReset(container);
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}


/*
 * date : 20180314
 * last : 20180314
 * name : funcTabComMoreAdd( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 추가시 탭item 추가
 * 호출시 funcTabComMoreAdd($(this), '.tab-com-more');
 */
function funcTabComMoreAdd (el, containerName, callback) {
	console.log (containerName )
	var tabcontainer = $(containerName);
	var tabs = $(containerName).find('.tabs').append(n);
	var parentsName = "'"+containerName+"'";
	var n = $(tabcontainer).find('.tab-item').length + 2;//임시 번호입니다.
	var tempname = '추가탭_' + n;//임시 이름입니다.
	
	var el = '<li class="tab_item tab-item" data-idx="'+n+'"><span class="tab_inner">'
				+ '<a href="#tab-cont1" class="tab-link" onclick="javascript:funcTabComMoreOnOff($(this), $(this).parents('+parentsName+')); return false;" ><span>'+tempname+'</span></a>'
				+ '<a href="javascript:;" class="tab-del ibtn_tab_del" onclick="javascript:funcTabComMoreDelete($(this), $(this).parents('+parentsName+')); return false;"><span class="offscreen">삭제</span></a>'
				+ '</span></li>';
	
	tabs.append(el);
	
	//reset 실행
	funcTabComMoreReset(containerName);
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	
	return false;
}










