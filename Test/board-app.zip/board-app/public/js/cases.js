/*
 * 파일명:		cases.js
 * 설  명 :		cases include
 * 작성자:		glim
 * 최초작성일:	2018/03/07
 * 최종수정일:	2018/03/13
 * Comment
 * 초기실행시 공통으로 필요한 함수들
 * 공통으로 들어갈경우 추후 페이지내 수정이 너무 많아질 것 같아서 임시 실행 호출 파일 입니다.)
 * 각 페이지에서만 필요한 스크립트는 각 페이지내에 작성예정
*/


//$(document).ready( function(){
$(function(){

	
});


//$(function () {
$(document).ready( function(){
	
});


/*
 * date : 20180313
 * update : 20180313
 * name : funcStarBtnToggle
 * pram : tg (클릭된 타겟)
 * dsec : 즐겨찾기 토글버튼
*/
function funcStarBtnToggle(el){
	var tg = $(el);
	
	if ( tg.hasClass("active") ){
		tg.removeClass("active");
		tg.find('.offscreen').text('즐겨찾기 해제');
	}else{
		tg.addClass("active");
		tg.find('.offscreen').text('즐겨찾기 설정');
	}			
}


/*
 * Com :: 전체 CASE QUICK VIEW Continaer Show/Hide 기능
 * date : 20180307
 * update : 20180313
 * case quick view Toggle 메뉴 리스트
 * Pram : tg this , container
*/
function toggleCasesQiuckView(tg, container){
	var container = $(container);

	if(container.hasClass('active') == true){
		container.removeClass('active');
		$('.cases_qview_inner.on').hide();
		$('.cases_qview_inner.off').show();

	}else{
		container.addClass('active');
		$('.cases_qview_inner.on').show();
		$('.cases_qview_inner.off').hide();
		
		
		//Case quick View tab setting
		if ($(".tab-cases-qview").length > 0) {
			$(".tab-cases-qview").each(function(n) {
				funcTabCasesQviewList($(this));
			});
			// 탭 업데이트시 'funcTabCasesQviewList(태그 리스트 jQuery Object)' 실행
			
			//tag-list reset 필요
			funcSetTagList($(".case-qview-detail-tag-list"));
		}
		
	}
}


/*
 * Com :: CASE QUICK VIEW Continaer 내에 탭 On/off 기능
 * date : 20180307
 * last : 20180309
 * name : funcCasesQiuckViewTabOnOff( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 On/off 탭 활성화
 */
function funcCasesQiuckViewTabOnOff (el, container, callback) {
	 	
	var tabitem = $(container).find(el).parents('.tab-item');
	var tabs = tabitem.parents('.tabs');
	var tg = $($(tabitem).find('.tab-link').attr("href"));//target container
	if ( $(tabitem).hasClass ("on") ){//클릭된타겟 활성화일경우 return
		return false;
	}
	//off
	var oldTabitem = $(tabs).find('> .tab-item.on');
	if ( oldTabitem.length > 0 ){
		//기존 활성화탭 off
		$(oldTabitem).removeClass('on');
		$($(oldTabitem).find('.tab-link').attr("href")).hide();//- 탭링크 컨텐츠 주석
	}
	
	//on
	tabitem.addClass('on');//tab active
	$(tg).show(0, function(){//tab show
		if ( callback != null && typeof callback === "function" ){
			callback.apply ( null, []);
		}
	});
	return false;
}


/*
 * Com :: CASE QUICK VIEW Continaer 내에 탭 슬라이드 기능
 * date : 20180307
 * last : 20180307
 * name : funcTabCasesQviewList( 컨테이너 )
 * pram :  target (container) 
 * Desc : 
 * 1. 7개 이상일때 좌우 화살표 생김 (탭 사이즈 고정)
 * 2. on/off 컨트롤은 별도 처리
 * 3. 자동 말줄임 css 처리 
 * 4. 이전목록/다음목록있을때만 css 처리하여 탭여백 조절
 */
function funcTabCasesQviewList(target) {
	var viewLen, btnsWidth, wrapper, tabWrapper, tabs, tabsList, tabTotalLen, viewWidth, viewTabWidth;
	viewLen = 7;							// 보여지는 갯수
	btnsWidth = 49;							// 좌우 화살표 영역 너비
	wrapper = $(target);					// 컨테이너 이름 ex) .tab-cases-qview
	tabWrapper = wrapper.find("> .mask");		// 보여지는 width target
	tabs = tabWrapper.find(" > .tabs");			// 전체 탭 el ex) ul.tabs
	tabsList = tabs.find("> .tab-item");	// 탭 전체 Array
	tabTotalLen = tabsList.length;			// 전체 탭 갯수	
	currentIndex = 0;						// 현재 제일 좌측에 보이는 태그의 index
	
	viewWidth = wrapper.width() - ((viewLen >= tabTotalLen) ? 0:btnsWidth);	// 보여지는 width 계산 (화살표 유무를 체크해서 width 계산/없으면 0/있으면 -버튼넓이)
	
	//삭제시, 탭추가시 초기화
	tabs.css({"left": 0});
	tabsList.removeClass('current-left current-view current-right');
	
	viewTabWidth = viewWidth / 7;//탭한개의 넓이 계산
	tabTotalWidth = tabTotalLen * viewTabWidth;//탭 전체 넓이 ul.tabs 넓이
	tabsList.css('width', viewTabWidth);//탭 한개 넓이 지정

	if (viewLen < tabTotalLen) {// 탭갯수가 보여질 갯수보다 큰 경우 / 좌우버튼 노출
		
		// s: 기본 셋팅
		tabWrapper.find("> .control-wrap.btns").css('opacity',1);

		// 초기 currentIndex가 0이므로 좌측 마스크 숨김
		tabWrapper.find("> .control-wrap.before").hide();
		tabWrapper.find("> .control-wrap.btns").find(".btn-prev").addClass('disabled');
		tabWrapper.find("> .control-wrap.after").show();
		tabWrapper.find("> .control-wrap.btns").find(".btn-next").removeClass('disabled');
		
		/* 
		.current-view 는 제일 좌측에 보여지는 탭의 index 체크하기 위한 class
		.current-left 는 제일 좌측에 보여지는 탭 의 여백
		.current-right 는 제일 우측에 보여지는 탭 의 여백
		*/
		tabsList.removeClass('current-left current-view current-right');
		tabsList.eq(currentIndex).addClass('current-view');//
		tabsList.eq(currentIndex).addClass('current-left');//제일 좌측 보여지는 탭
		tabsList.eq( currentIndex+viewLen-1).addClass('current-right');

		// e: 기본 셋팅
		
		
		// 이전 버튼 클릭 이벤트
		tabWrapper.find("> .control-wrap.btns .btn-prev").off("click").on("click", function(event) {
			currentIndex = tabs.find(".current-view").index();
			
			if (currentIndex > 1) {//일반 이전
				currentIndex--;
			}else if (currentIndex == 1) {//마지막이전
				currentIndex--;
				tabWrapper.find("> .control-wrap.before").hide();
				tabWrapper.find("> .control-wrap.btns").find(".btn-prev").addClass('disabled');
			}
			
			tabWrapper.find("> .control-wrap.after").show()
			tabWrapper.find("> .control-wrap.btns").find(".btn-next").removeClass('disabled');
			
			tabs.css({
				"left": -(currentIndex * viewTabWidth)
			});
			
			tabsList.removeClass('current-left current-view current-right');
			tabsList.eq(currentIndex).addClass('current-left').addClass('current-view');
			tabsList.eq( currentIndex+viewLen-1).addClass('current-right');
			
		});

		// 다음 버튼 클릭 이벤트
		tabWrapper.find("> .control-wrap.btns .btn-next").off("click").on("click", function(event) {
			if(tabWrapper.find("> .control-wrap.btns").find(".btn-next").hasClass('disabled') == true){return;}
			currentIndex = tabs.find(".current-view").index();
			
			//좌측 마스크 노출
			tabWrapper.find("> .control-wrap.before").show();
			tabWrapper.find("> .control-wrap.btns").find(".btn-prev").removeClass('disabled');
			
			var a =  tabTotalLen - (currentIndex + viewLen);
			
			if ( a > 1 ){//보여줄거있음
				currentIndex++;
			}else if (a == 1){//보여주면 마지막
				currentIndex++;
				tabWrapper.find("> .control-wrap.after").hide();
				tabWrapper.find("> .control-wrap.btns").find(".btn-next").addClass('disabled');
			}
			
			tabs.css({
				"left": -(currentIndex * viewTabWidth)
			});
			
			tabsList.removeClass('current-left current-view current-right');
			tabsList.eq(currentIndex).addClass('current-left').addClass('current-view');
			tabsList.eq( currentIndex+viewLen-1).addClass('current-right');
		});
		
	}else{//탭갯수가 보여질 갯수보다 작을 경우 / 좌우버튼 비노출
		tabWrapper.width(viewWidth);
		tabWrapper.find("> .control-wrap").hide();
	}
	
}


/*
 * Com :: CASE QUICK VIEW Continaer 내에 탭 삭제 기능
 * date : 20180307
 * last : 20180307
 * name : funcCasesQviewTabDelete( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 삭제 (morelist 에 나오는 탭 경우 2개임)
 */
function funcCasesQviewTabDelete (el, container, callback) {
	var tabcontainer = $(container);
	var tabitem = $(container).find(el).parents('.tab-item');
	var delidx = $(tabitem).data('idx');//delete idx
	
	var delTab = tabcontainer.find("[data-idx='" + delidx + "']");
	tabcontainer.find(delTab).remove();
	
	//reset
	funcTabCasesQviewList(container);
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}



/*
 * Com :: CASE QUICK VIEW Continaer 내에 > Quick view List 열기/접기 기능
 * date : 20180307
 * last : 20180313
 * case quick view list Toggle 메뉴 리스트
 * Pram : tg this , container
*/
function toggleCasesQiuckViewList(tg, container){
	var container = $(container);
	if(container.hasClass('active') == true){
		container.removeClass('active');
		$('.qview_list_inner.on').hide();
		$('.qview_list_inner.off').show();

	}else{
		container.addClass('active');
		$('.qview_list_inner.on').show();
		$('.qview_list_inner.off').hide();
	}
	
	
	//quickviewlist 변화시 호출필요
	funcTabCasesQviewList('.tab-cases-qview');
	
	
	//quickviewlist 변화시 case 내에 있는 tag-list 도 reset 필요
	funcSetTagList('.case-qview-detail-tag-list');
}



/*
 * Com :: CASE QUICK VIEW Continaer > alarms/acoi ... ./File 탭 컨탠츠 내에 리스트 fold 기능
 * date : 20180309
 * last : 201800309 (다중사용으로 selector 변경)
 * name : foldOnOff( 선택자, 상위 선택자, 보여지는 컨텐츠 선택자, 콜백함수 )
 * pram :  el (target) / container (parent) / tg (target ele selector)
 */
function foldOnOff (el, container, callback) {
	var li = $(el).parents('li');
	
	if ( li.hasClass('open') == true ){
		li.removeClass('open');
	}else{
		li.addClass('open');
	}
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}



