/*
 * 파일명:		report.js
 * 설  명 :		report 탭 컨트롤 페이지
 * 작성자:		khj
 * 최초작성일:	2018/04/02
 * 최종수정일:	2018/04/02
 * Comment
 * 탭관련되어 임시 로직들 
 * 개발에 맞추어 작업하시면 될것같습니다.
 * funcreportTabOnOff 는 기존 함수와 동일한 로직입니다. 
 * tab-link 탭링크에  href="#탭컨텐츠이름" 으로 사용하시고 페이지 주석부분 해제시 동일하게 동작가능
*/


/**
 * 
 * 추가 : 20180622 @author A0801278 엄성관
 * 
 * 추가함수 : initAsset()
 *           gettAsset()
 *           '취소' 이벤트 한번만 호출하게 변경. 20180625_ $('#btnCancel').click => $('#btnCancel').unbind("click").bind("click", function(){ }
 *                                 
 */

// Asset Model List 팝업창에서 선택한 객체 20180622_ 추가
var Gasset = {};
var Gpopasset = {};


    $(document).ready( function(){
 	
		//report Tab 실행
		/*
        if ( $('.tab-report').length > 0 ){	
			funcReportTabReset('.tab-report');
		}
		*/
	});
	
/*
 * date : 20180508
 * last : 20180508
 * name : objToJson( serializeArray() )
 * pram :  formDataArray (serializeArray())
 * Desc : 폼 데이터를 받아서 json 데이터로 변환 하는 함수
 */
function objToJson(formDataArray){

	var data = formDataArray;

	var obj = {};

	$.each(data, function(idx, ele){

		obj[ele.name] = ele.value;

	});

	return JSON.stringify(obj);
}


/*
 * date : 20180302
 * last : 20180302
 * name : funcReportTabReset( 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭이 14개 이상 일 경우 더보기 버튼 생성 (14 이상은 보이지 않음)
   -. 삭제/추가시 탭 변동시 무조건 호출필요
   -. 기존 ul 에 추가되며 14개보다 많아질경우 더보기 버튼/목록 생성되고 
   -. 많아질경우 기존 ul 은 나두고 더보기 컨테이너에 컨텐츠 추가함
 */
function funcReportTabReset (container){
	var viewTabLen = 14;
	var btnMoreWidth = 34;
	var container = $(container);
	/*
	var btnMore = container.find('.tab-more');
	var tabMoreListContainer = container.find(".tab-more-list-wrap")
	var tabMoreListUl = container.find(".tab-more-list-ul")
	var tabitem = $('> .tabs', container).find('.tab-item');
	var tabitemMore = $('.tabs', container).find('.tab-item:gt('+(viewTabLen-1)+')');//더보기로 clone 시킬 item
	var viewWidth = container.width() - btnMoreWidth;
	tabitem.css('width', viewWidth/viewTabLen);
		
	if (tabitem.length > viewTabLen) {//14개보다 많을 때
		btnMore.show();
		
		tabMoreListUl.empty();
		tabitemMore.each(function(n) {
			tabMoreListUl.append($(this).removeAttr('style').clone());
		});
		
	}else{
		btnMore.hide();
	}
	*/



}

/*
 * date : 20180302
 * last : 20180302
 * name : funcReportTabMoreOnOff( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 더보기 영역 onoff
 */
/*
function funcReportTabMoreOnOff (el, container){
	var container = $('.tab-report');
	var tg = '.tab-more-list-wrap';
	
	if ( container.find( tg+":visible").length > 0 ){//감춰라
		$(tg).hide();
	}else{//보여줘라
		$(tg).show();
	}
}
*/

/*
 * date : 20180302
 * last : 20180302
 * name : funcReportTabOnOff( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 On/off 탭 활성화
 */
function funcReportTabAdd (container, tabName) {
	var tabcontainer = $(container);
	var parentsName = container;
	var tempname = tabName;//report ID
	var tabCount = $(container).find('li').length +1;
	var tabs = $(tabcontainer).find('.tabs').append(tabCount);

	tabcontainer.find('li').removeClass('on');	
	
	var el = '<li class="tab_item tab-item on" data-idx="'+tabCount+'" value="'+tabName+'"><span class="tab_inner">'
				+ '<a href="#tab_cont_'+tabCount+'" class="tab-link"  onclick="javascript:funcReportTabOnOff($(this), $(this).parents(\'.tab-report\'));return false;" ><span>'+tempname+'</span></a>'
				+ '<a href="#tab_cont_'+tabCount+'" class="tab-del ibtn_report_tab_del" onclick="javascript:funcReportTabDelete($(this), $(this).parents(\'.tab-report\')); return false;"><span class="offscreen">삭제</span></a>'
				+ '</span></li>';
	
	//tabcontainer.append(el);
	tabs.append (el);

	
	//reset 실행
	funcReportTabReset('.tab-report');

	/*
        var tabcontainer = $(containerName);
        var tabs = $(containerName).find('.tabs').append(n);
        var parentsName = "'"+containerName+"'";
        var n = $(tabcontainer).find('.tab-item').length;//임시 번호입니다.
        var tempname = '추가탭_' + n;//임시 이름입니다.
        

        //기존 활성화탭 off
        var oldTabitem = $(containerName).find('.tab-item.on');
        if ( oldTabitem.length > 0 ){            
            $(oldTabitem).removeClass('on');
        }       

        var el = '<li class="tab_item tab-item on" data-idx="'+n+'"><span class="tab_inner">'
                    + '<a href="#tab-cont1" class="tab-link" onclick="javascript:funcTabComMoreOnOff($(this), $(this).parents('+parentsName+')); return false;" ><span>'+tempname+'</span></a>'
                    + '<a href="javascript:;" class="tab-del ibtn_tab_del" id=' + tempname + '><span class="offscreen">삭제</span></a>'
                    + '</span></li>';
        
        tabs.append (el);
	
	*/
	return false;
}


/*
 * date : 20180302
 * last : 20180302
 * name : funcAlarmTabOnOff( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 On/off 탭 활성화
 */
/*
function funcReportTabOnOff (el, container, callback) {
	 	
	var tabitem = $(container).find(el).parents('.tab-item');
	//var tg = $($(tabitem).find('.tab-link').attr("href"));//target container - 탭링크 컨텐츠 주석
	if ( $(tabitem).hasClass ("on") ){//클릭된타겟 활성화일경우 return
		return false;
	}
	//off
	var oldTabitem = $(container).find('.tab-item.on');
	if ( oldTabitem.length > 0 ){
		//기존 활성화탭 off
		$(oldTabitem).removeClass('on');
		//$($(oldTabitem).find('.tab-link').attr("href")).hide();//- 탭링크 컨텐츠 주석
	}
	
	//on
	tabitem.addClass('on');//tab active
	
	 $(tg).show(0, function(){//tab show - 탭링크 컨텐츠 주석
		if ( callback != null && typeof callback === "function" ){
			callback.apply ( null, []);
		}
	}); 
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}
*/


/* 탭 추가시 탭item 추가 */
/*
function profileTabComMoreAdd (containerName, callback) {
	var tabcontainer = $(containerName);
	var tabs = $(containerName).find('.tabs').append(n);
	var parentsName = "'"+containerName+"'";
	var n = $(tabcontainer).find('.tab-item').length;//임시 번호입니다.
	var tempname = '추가탭_' + n;//임시 이름입니다.
	

	//기존 활성화탭 off
	var oldTabitem = $(containerName).find('.tab-item.on');
	if ( oldTabitem.length > 0 ){            
		$(oldTabitem).removeClass('on');
	}       

	var el = '<li class="tab_item tab-item on" data-idx="'+n+'"><span class="tab_inner">'
				+ '<a href="#tab-cont1" class="tab-link" onclick="javascript:funcTabComMoreOnOff($(this), $(this).parents('+parentsName+')); return false;" ><span>'+tempname+'</span></a>'
				+ '<a href="javascript:;" class="tab-del ibtn_tab_del" id=' + tempname + '><span class="offscreen">삭제</span></a>'
				+ '</span></li>';
	
	tabs.append (el);

	// TODO : 버그 수정 필요.
	//Playbook Tab Delete Click 이벤트
	$('#'+ tempname).click(function () {
		var tabitem = $(this).parents('.tab-item');
		var delidx = $(tabitem).data('idx');//delete idx            
		var delTab = tabcontainer.find("[data-idx='" + delidx + "']");
		tabcontainer.find(delTab).remove();
		//reset 실행
		//this.playbookTabComMoreReset(containerName);
	});                
	
	//reset 실행
	//this.playbookTabComMoreReset(containerName);
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	
	return false;
}
*/


function tabComMoreOnOff(el, container, callback) {		
	funcTabComMoreOnOff(el, container, callback);
} 

/* 탭 추가시 탭item 추가 */
function profileTabComMoreAdd (containerName, tabName, callback) {
	var tabcontainer = $(containerName);
	var tabs = $(containerName).find('.tabs').append(n);
	var parentsName = "'"+containerName+"'";
	var n = $(tabcontainer).find('.tab-item').length;//임시 번호입니다.
	//var tempname = '추가탭_' + n;//임시 이름입니다.
	// var tempname = tabName + n;//임시 이름입니다.
	var tempname = tabName;
	var searchArea = $("#profile_search_area");
	var contentArea = $("#profile_block_content_area");

	searchArea.children().css("display", "none");
	contentArea.children().css("display", "none");


	//기존 활성화탭 off
	var oldTabitem = $(containerName).find('.tab-item.on');
	if ( oldTabitem.length > 0 ){            
		$(oldTabitem).removeClass('on');
	}       

	var el = '<li class="tab_item tab-item on" data-idx="'+n+'"><span class="tab_inner">'
				+ '<a href="#tab-cont1" class="tab-link" name="tab_link"><span>'+tempname+'</span></a>'
				+ '<a href="javascript:;" class="tab-del ibtn_tab_del" id=' + tempname + '><span class="offscreen">삭제</span></a>'
				+ '</span></li>';
	
	tabs.append (el);

	var top_search_block_tabs_html = addReportSearchBlockTabs(n);
	//var top_content_block_tabs_html = addRuleBlockTabs(n);
	var top_content_block_tabs_html = "";

	$("#profile_search_area").append(top_search_block_tabs_html);
	//$("#profile_block_content_area").append(top_content_block_tabs_html);
	//$("#tab-cont"+n).show();

	var searchTabsId = "profile_search_tabs"+n;
	var contentTabsId = "tab-cont"+n;
	$("#"+searchTabsId).css("display", "block");	
	setTimeout(() => {
		$("#"+contentTabsId).css("display", "block");
	}, 200);
	

	//$('#'+ tempname).click(function () {
	$('.tab-del').click(function () {
		//alert("AA");
		var tabitem = $(this).parents('.tab-item');
		var delidx = $(tabitem).data('idx');//delete idx            
		var delTab = tabcontainer.find("[data-idx='" + delidx + "']");
		var topTab = tabcontainer.find("[data-idx=0]");

		tabcontainer.find(delTab).remove();
		$("#tab-cont"+delidx).hide();
		$("#profile_search_tabs0").show();
		$("#tab-cont0").show();
		$("#pro_mgmt_main_tab").addClass("on");
		//tabcontainer.find(topTab).find('li').attr.;
		
		//reset 실행
		//_.profileTabComMoreDelete(containerName);
	});

	  //$('#btnCancel').click(function () {
	  // '취소' 이벤트 한번만 호출하게 변경. click => .unbind("click").bind("click", function(){ }
	  $('#btnCancel').unbind("click").bind("click", function(){  
		
		if(confirm("현재까지 선택된 정보를 삭제합니다.\n취소하시겠습니까?")==true){
			//var tabitem = $(this).parents('.tab-item');
			var tabitem = $(containerName).find('.tab-item.on');
			var delidx = $(tabitem).data('idx');//delete idx            
			var delTab = tabcontainer.find("[data-idx='" + delidx + "']");
			var topTab = tabcontainer.find("[data-idx=0]");

			tabcontainer.find(delTab).remove();
			$("#tab-cont"+delidx).hide();
			$("#profile_search_tabs0").show();
			$("#tab-cont0").show();
			//tabcontainer.find(topTab).find('li').attr.;
				
			//reset 실행
			//var oldTabitem = $(containerName).find('.tab-item.on');
			//profileTabComMoreDelete(oldTabitem, containerName);
		}
		
	});


	//searchArea.children().addClass("hide");
	//jQuery('#profile_search_area').css("display", "block");   

	// TODO : 버그 수정 필요.
	//Playbook Tab Delete Click 이벤트
					
	
	//reset 실행
	//_.profileTabComMoreReset(containerName);
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}	
	return false;
}

/* 탭 추가시 14개가 넘으면 더보기 생성 */
function profileTabComMoreReset(container) {
	var viewTabLen = 12;
	var btnMoreWidth = 34;
	var container = $(container);
	var btnMore = container.find('.tab-more');
	var tabMoreListContainer = container.find(".tab-more-list-wrap")
	var tabMoreListUl = container.find(".tab-more-list-ul")
	var tabitem = $('.tabs', container).find('.tab-item');
	var tabitemMore = $('.tabs', container).find('.tab-item:gt('+(viewTabLen-1)+')');//더보기로 clone 시킬 item
	var viewWidth = container.width() - btnMoreWidth;
	tabitem.css('width', viewWidth/viewTabLen);
	tabMoreListContainer.hide();
	
	if (tabitem.length > viewTabLen) {//14개보다 많을 때
		btnMore.show();
		
		tabMoreListUl.empty();
		tabitemMore.each(function(n) {
			tabMoreListUl.append($(this).removeAttr('style').clone());
		});
		
	}else{
		btnMore.hide();
	}
}    

/* 탭 더보기 영역 onoff */
function funcTabComMoreListOnOff (){
	var _container = $('.tab-com-more');
	var _tg = $('.tab-more-list-wrap');
	
	if ( _container.find( ".tab-more-list-wrap" + ":visible").length > 0 ){//감춰라
		$(_tg).hide();
	}else{//보여줘라
		$(_tg).show();
	}
}

/* 탭 삭제 (morelist 에 나오는 탭 경우 2개임) */
function profileTabComMoreDelete (el, container, callback) {
/* 
	var tabcontainer = $(container);
	//var tabitem = $(container).find(el).parents('.tab-item');
	var tabitem = $(container).find('.tab-item.on');
	var delidx = $(tabitem).data('idx');//delete idx
	
	var delTab = tabcontainer.find("[data-idx='" + delidx + "']");
	tabcontainer.find(delTab).remove();
 */

	var tabcontainer = $(container);
	var tabitem = $(container).find('.tab-item.on');
	var delidx = $(tabitem).data('idx');//delete idx            
	var delTab = tabcontainer.find("[data-idx='" + delidx + "']");
	var topTab = tabcontainer.find("[data-idx=0]");

	tabcontainer.find(delTab).remove();
	$("#tab-cont"+delidx).hide();
	$("#profile_search_tabs0").show();
	$("#tab-cont0").show();

	//reset
	//this.profileTabComMoreReset(container);        
	/*
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
	*/
}

function funcReportTabMoreOnOff(){
	funcReportTabMoreOnOff();
} 

function addReportSearchBlockTabs(idx){
    var html = '';
    
    html+='<div id="profile_search_tabs'+idx+'" data-idx="'+idx+'" style="display:block;">';
    html+='</div>';
    
	return html;
}


// 20180622_ 추가 
function  initAsset() { 
	
	// 선택박스 초기화.
	$("input[id^='ip-chk1-']").each(function(){  
		var id = $(this).attr("id");  
	    if ($('#'+id).is(":checked")) { 
            $('#'+id).prop('checked', false) ;
		}
	});
}

// Asset Model List 팝업창에서 기존에 저장되어진 Asset 은 선택 되어져서 보여지게 한다. // 20180622_ 추가 
function gettAsset(object) {

	initAsset();

    $("input[id^='ip-chk1-']").each(function(){  
		var inputId = $(this).attr("id");  
		var id = $(this).attr("data-id");   // alert(id);
	    for(var i=0; i < Gasset.length; i++){
           if (Gasset[i].asstId == id){
			   // alert('1');
			   $('#'+inputId).prop('checked', true) ;
		   }
		}
	});
	

}