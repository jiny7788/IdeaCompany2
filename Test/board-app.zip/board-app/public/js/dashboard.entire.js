/*
 * 파일명:		dashboard.entire.js
 * 설  명 :		dashboard > Entire Status실행필요한 함수 include 
 * 작성자:		glim
 * 최초작성일:	2018/01/23
 * 최종수정일:	2018/02/13
 * Comment
 * 초기실행시 공통으로 필요한 함수들
 * 공통으로 들어갈경우 추후 페이지내 수정이 너무 많아질 것 같아서 임시 실행 호출 파일 입니다.)
 * 각 페이지에서만 필요한 스크립트는 각 페이지내에 작성예정
*/
 

/*
 * date : 20180124
 * last : 20180125
 * name : viewTypeChange( 클릭타겟, 변경타겟 클래스아이디명 )
 * pram :  el (target) / tg (target ele selector)
 */
function viewTypeChange(el, tg){
	var _el = $(el),_tg = $(tg);
	var val = _el.find("option:selected").val();//selectTg
	_tg.removeClass('col3 col4 col5 col6').addClass('col'+val);
}
/*
 * date : 20180124
 * last : 20180213
 * name : viewTypeChange( 클릭타겟, 변경타겟 클래스아이디명 )
 * pram :  el (target) / tg (target ele selector)
 * qiuckView 활성화시 열변경은 disable 처리
 * 20180213 - select 변경으로 disable 처리 추가
 */
function viewTypeChangeQiuck (el, tg){
	var _el = $(el),_tg = $(tg);
	var _view_col_select = $(".view-type-value");
	var _btn_mapview = $(".btn-mapview");
	/* var val = _el.find("option:selected").val();//selectTg */
	if ( _tg.hasClass('col8') ){
		_tg.removeClass('col8');
		_el.text('Qiuck View');
		_btn_mapview.removeClass('disabled');//20180213 수정
		_view_col_select.prop('disabled', '');
	}else {
		_tg.addClass('col8');	
		_el.text('Normal View');
		_view_col_select.prop('disabled', 'disabled');
		_btn_mapview.addClass('disabled');//20180213 수정
	}
	//201780212 select disable 처리 추가
	_view_col_select.data('selectric').refresh();
}

/*
 * date : 20180124
 * last : 20180213
 * name : viewTypeChangeMap( 클릭타겟, 변경타겟 클래스아이디명 )
 * pram :  el (target) / tg (target ele selector)
 * qiuckView 활성화시 열변경은 disable 처리
 */
function viewTypeChangeMap (el, tg){
	var _el = $(el),_tg = $(tg);
	if ( _el.hasClass('disabled') ) return false;//20180213 disable 처리시 리턴
	if ( _tg.hasClass('map-off') ){
		_tg.removeClass('map-off');
		_el.text('지도 ON');
	}else {
		_tg.addClass('map-off');	
		_el.text('지도 OFF');
	}
}


