/*
 * 파일명:		dashboard.asset.js
 * 설  명 :		dashboard > Asset 실행필요한 함수 include
 * 작성자:		glim
 * 최초작성일:	2018/02/20
 * 최종수정일:	2018/02/20
 * Comment
 * 초기실행시 공통으로 필요한 함수들
 * 공통으로 들어갈경우 추후 페이지내 수정이 너무 많아질 것 같아서 임시 실행 호출 파일 입니다.)
 * 각 페이지에서만 필요한 스크립트는 각 페이지내에 작성예정
*/



//$(document).ready( function(){
$(function(){


	$( window ).resize( function() { autoHeight(); });
	autoHeight();

	/* Minimap */
	if ( $( "#minimap" ).length > 0 ){

		// Add children to the parent.
		var $parent = $( "#minimapParent" );
		// Now invoke the minimap method on the element you'd like to become the minimap,
		// passing a reference to the element you'd like the map to be based on.
		$( "#minimap" ).minimap( $parent );
	}
	/* E: Minimap */


	/* TooltipMenu */
	//.asset_lists > .item

	//Calling context menu
	/* $('.item').contextMenu('.nv-context-menu', {

	}); */

/* 	var _tooltipList;
	var _timerTooltip;

	if ( $( ".asset_lists" ).length > 0 ){
		_tooltipList = $( ".btn-tooltip", '.asset_lists');
		_tooltipList.each(function(n) {

			var tag = $(this).data("title");
			$(this).append("<div class='tooltip_box tooltip-box'></div>");
			$(this).find('.tooltip-box').append(tag);

			$(this).hover(function(){
				clearTimeout(_timerTooltip);
				var link = $(this);
				_timerTooltip = window.setTimeout(function(){

					var tbox = $(link).find('.tooltip-box');
					var papa = $(link).parents('.tooltip-container');
					var btn = $(link);

					//Adjust Position
					var papaRight = parseInt(parseInt(papa.offset().left) + papa.outerWidth() - 18);
					var papaBottom = parseInt(parseInt(papa.offset().top) + papa.outerHeight() - 18);

					var tRight = parseInt(parseInt(btn.offset().left) +tbox.outerWidth());
					var tBottom = parseInt(parseInt(btn.offset().top) + tbox.outerHeight());

					//console.log ("## papa :",  papaRight, papaBottom);
					//console.log ("## elel :", tRight, tBottom);


					if ( tRight > papaRight ){//adjust right
						tbox.addClass('right');
					}

					if ( tBottom > papaBottom ){//adjust bottom
						tbox.addClass('bottom');
					}

					//open after 3sec
					$(link).addClass('tooltip-on');
				}, 3000);
			});

			$(this).on("mouseleave",function() {
				clearTimeout(_timerTooltip);
				$(this).removeClass('tooltip-on');
				$(this).find('.tooltip-box').removeClass("right bottom");
			});

			$(this).on("click",function() {
				clearTimeout(_timerTooltip);

				var tbox = $(this).find('.tooltip-box');
				var papa = $(this).parents('.tooltip-container');
				var btn = $(this);

				//Adjust Position
				var papaRight = parseInt(parseInt(papa.offset().left) + papa.outerWidth() - 18);
				var papaBottom = parseInt(parseInt(papa.offset().top) + papa.outerHeight() - 18);

				var tRight = parseInt(parseInt(btn.offset().left) +tbox.outerWidth());
				var tBottom = parseInt(parseInt(btn.offset().top) + tbox.outerHeight());

				//console.log ("## papa :",  papaRight, papaBottom);
				//console.log ("## elel :", tRight, tBottom);

				if ( tRight > papaRight ){//adjust right
					tbox.addClass('right');
				}

				if ( tBottom > papaBottom ){//adjust bottom
					tbox.addClass('bottom');
				}

				//open
				$(this).addClass('tooltip-on');
			});

		});
	} */

});


/* Asset View*/
function autoHeight(){
	//console.log ( "asset autoHeight");
	$( document.body ).addClass("scroll-auto");

	$(".dashboard .body_content").css("height","100%");
}


/*
* date : 20180221
* update : 20180221
* 알람List Toggle 메뉴 리스트
* Pram : tg this 호출 가장 근접한 asset_wrap 을 찾음  
*/
function toggleList(tg){
	var tgAnswer = $(tg).parents('.asset_wrap');
	if(tgAnswer.hasClass('active') == true){
		tgAnswer.removeClass('active');
		$('.alarm_inner.on').hide();
		$('.alarm_inner.off').show();

	}else{
		tgAnswer.addClass('active');
		$('.alarm_inner.on').show();
		$('.alarm_inner.off').hide();
	}
}





