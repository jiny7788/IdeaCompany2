/*
 * 파일명:		alarm.js
 * 설  명 :		alarm 탭 컨트롤 페이지
 * 작성자:		glim
 * 최초작성일:	2018/03/02
 * 최종수정일:	2018/03/02
 * Comment
 * 탭관련되어 임시 로직들 
 * 개발에 맞추어 작업하시면 될것같습니다.
 * funcAlarmTabOnOff 는 기존 함수와 동일한 로직입니다. 
 * tab-link 탭링크에  href="#탭컨텐츠이름" 으로 사용하시고 페이지 주석부분 해제시 동일하게 동작가능
*/
 
//$(window).on("load", function (e) {
	/*
$(document).ready( function(){
 	
	//alarm Tab 실행
	if ( $('.tab-alarm').length > 0 ){
		funcAlarmTabReset('.tab-alarm');
	}
	
});
*/

/*
 * date : 20180302
 * last : 20180314 bug update
 * name : funcAlarmTabReset( 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭이 14개 이상 일 경우 더보기 버튼 생성 (14 이상은 보이지 않음)
   -. 삭제/추가시 탭 변동시 무조건 호출필요
   -. 기존 ul 에 추가되며 14개보다 많아질경우 더보기 버튼/목록 생성되고 
   -. 많아질경우 기존 ul 은 나두고 더보기 컨테이너에 컨텐츠 추가함
 */
/*
function funcAlarmTabReset (container){
	console.log ("funcAlarmTabReset");
	var viewTabLen = 14;
	var btnMoreWidth = 34;
	var container = $(container);
	var btnMore = container.find('.tab-more');
	var tabMoreListContainer = container.find(".tab-more-list-wrap")
	var tabMoreListUl = container.find(".tab-more-list-ul")
	var tabitem = $('> .tabs', container).find('.tab-item');
	var tabitemMore = $('.tabs', container).find('.tab-item:gt('+(viewTabLen-1)+')');//더보기로 clone 시킬 item
	var viewWidth = container.width() - btnMoreWidth;
	tabitem.css('width', viewWidth/viewTabLen);
	tabMoreListContainer.hide();
		
	if (tabitem.length > viewTabLen) {//14개보다 많을 때
		btnMore.show();
		
		tabMoreListUl.empty();
		tabitemMore.each(function(n) {
			tabMoreListUl.append($(this).removeAttr('style').clone());
		});
		
	}else{
		btnMore.hide();
	}
}
*/

/*
 * date : 20180302
 * last : 20180302
 * name : funcAlarmTabMoreOnOff( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 더보기 영역 onoff
 */
/*
function funcAlarmTabMoreOnOff (el, container){
	var container = $('.tab-alarm');
	var tg = '.tab-more-list-wrap';
	
	if ( container.find( tg+":visible").length > 0 ){//감춰라
		$(tg).hide();
	}else{//보여줘라
		$(tg).show();
	}
}
*/


/*
 * date : 20180302
 * last : 20180302
 * name : funcAlarmTabOnOff( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 On/off 탭 활성화
 */
/*
function funcAlarmTabOnOff (el, container, callback) {
	 	
	var tabitem = $(container).find(el).parents('.tab-item');
	//var tg = $($(tabitem).find('.tab-link').attr("href"));//target container - 탭링크 컨텐츠 주석
	if ( $(tabitem).hasClass ("on") ){//클릭된타겟 활성화일경우 return
		return false;
	}
	//off
	var oldTabitem = $(container).find('.tab-item.on');
	if ( oldTabitem.length > 0 ){
		//기존 활성화탭 off
		$(oldTabitem).removeClass('on');
		//$($(oldTabitem).find('.tab-link').attr("href")).hide();//- 탭링크 컨텐츠 주석
	}
	
	//on
	tabitem.addClass('on');//tab active
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}
*/


/*
 * date : 20180302
 * last : 20180302
 * name : funcAlarmTabDelete( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 삭제 (morelist 에 나오는 탭 경우 2개임)
 */
/*
function funcAlarmTabDelete (el, container, callback) {
	var tabcontainer = $(container);
	var tabitem = $(container).find(el).parents('.tab-item');
	var delidx = $(tabitem).data('idx');//delete idx
	
	var delTab = tabcontainer.find("[data-idx='" + delidx + "']");
	tabcontainer.find(delTab).remove();
	
	//reset
	funcAlarmTabReset('.tab-alarm');
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}
*/


/*
 * date : 20180302
 * last : 20180302
 * name : funcAlarmTabAdd( 클릭타겟, 컨테이너 )
 * pram :  el (target) / tg (target ele selector) / callback
 * Desc : 탭 추가시 탭item 추가
 */
/*
function funcAlarmTabAdd (el, container, callback) {
	var tabcontainer = $(container);
	var tabs = $(container).find('.tabs').append(n);
	var parentsName = "'.tab-alarm'";
	var n = $(tabcontainer).find('.tab-item').length + 2;//임시 번호입니다.
	var tempname = '추가탭_' + n;//임시 이름입니다.
	
	var el = '<li class="tab_item tab-item" data-idx="'+n+'"><span class="tab_inner">'
				+ '<a href="#tab-cont1" class="tab-link" onclick="javascript:funcAlarmTabOnOff($(this), $(this).parents('+parentsName+')); return false;" ><span>'+tempname+'</span></a>'
				+ '<a href="javascript:;" class="tab-del ibtn_alarm_tab_del" onclick="javascript:funcAlarmTabDelete($(this), $(this).parents('+parentsName+')); return false;"><span class="offscreen">삭제</span></a>'
				+ '</span></li>';
	
	tabs.append (el);
	
	//reset 실행
	funcAlarmTabReset('.tab-alarm');
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	
	return false;
}
*/










