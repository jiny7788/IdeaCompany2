/*
 파일명:		front.ui.js
 기능설명:		공통 자바스크립트
 작성자:		glim
 최초작성일:	2017/11/20
 최종수정일:	2018/03/19
 - 레이아웃 수정 - 
 20180213 개발요청으로 header main/sub 분리
 20180319 jquery tooltip add
*/

/* 20171205 삭제
var _gnb;
var _mnbSelectId = [];// = [1,2];/*활성화된 메뉴 0 부터 카운트됨*/

$(document).ready( function(){
	
	try {
		//tooltip defualt setting 20180319 add
		$.widget("ui.tooltip", $.ui.tooltip, {
			options: {
				show:{effect:"none"},
				hide:{effect:"none"},
				content: function () {
					return $(this).data('tooltip'); 
				},
				close: function (){
					$('.ui-helper-hidden-accessible').empty();
				}
			}
		});
	}
	catch(exception){
		//catchStatements
	}
	
	$( window ).resize( function() { resize(); });
	resize();
		
})
	

function resize (){
	//console.log ("resize");
	
	funcGnbSetHeight();
}

/*
 * date : 20180118
 * update :  20180213
 * name : funcGnbSetHeight
 * pram : dragEl (drag target), dropEl (drop target)
 * dsec : 공통 Gnb 검색 접히는 부분 높이값 초기화 
 * 메뉴 컨텐츠마다 높이값이 가변이라 초기화 실행 필요
 * 항목 변경시 호출필요
*/
function funcGnbSetHeight (){
	//console.log ( "funcGnbSetHeight ");
	var subHeight = ($(".header_sub").length > 0 ) ? $(".header_sub").outerHeight():0;
	var topPad = $(".header_main").outerHeight() + subHeight;
	var conHeight = $(window).height() - topPad -5;
	//console.log ("~~conHeight", $(".header_main").outerHeight(), ($(".header_sub").length > 0 ) ? $(".header_sub").outerHeight():0)
	$('.body').css ("padding-top", topPad).css("min-height", conHeight).css("height", conHeight);
}

/*
 * date : 20180118
 * update : 20180213
 * name : funcGnbToggle
 * pram : 
 * dsec : Gnb 하위 검색 Toggle 영역 
*/
function funcGnbToggle (container , tg){
	var _container = $(container);
	var _tg = $(tg);
	
	if (_container.find(".hidden-group").hasClass('hidden')){
		_container.removeClass("fold_menu");
		_container.find(".hidden-group").removeClass('hidden');
		var topPad = $(".header_main").outerHeight() + $(".header_sub").outerHeight();
	}else{
		_container.addClass("fold_menu");
		_container.find(".hidden-group").addClass('hidden');
		var topPad = $(".header_main").outerHeight() + $(".header_sub").outerHeight();
	}

	var conHeight = $(window).height() - topPad;
	$('.body').css("padding-top", topPad).css("min-height", conHeight).css("height", conHeight);
}


/*
 * date : 20180313
 * update : 20180313
 * name : funcAdminHeaderToggle
 * pram : 
 * dsec : Admin Header Toggle 
*/
function funcAdminHeaderToggle (container , tg){
	//console.log ( "funcAdminHeaderToggle" );
	var _container = container;
	var _tg = $(tg);
	var topPad, conHeight;
	if ( $(_container).hasClass('hidden') ){
		$(_container).removeClass('hidden');
		_tg.show();
	}else{
		$(_container).addClass('hidden');
		_tg.hide();
	}
}
/****************************************
* GNB
GNB 활성화 방법 (0 부터 카운트됨)
_mnbSelectId = [0,0]; << 해당 부분이 상단에 선언되어있을시 _gnb.mnbFocus(); 별도 호출하지않아도 작동
실행 초기화는 front.ui.js 
*****************************************/
function GnbObj (id){
	this.getElement = $(id);
	this.len = this.getElement.find("li").length;
	this.bdTimer = null;
}
GnbObj.prototype.init = function(){

	//console.log ( _mnbSelectId, this.name )
	$('>li',this.getElement).each(function(i) {
		$(this).attr("id","gnb_"+i);
		$(this).find('.gnb_sub_item').each(function(j) {
			$(this).attr("id","gnb_"+i+"_"+j);
		});
		
		//hover
		$(this).mouseover(function(e){	
			var tgId = $(e.currentTarget).attr('id');
			//console.log ( tgId, this.getElement);
			
			$('> li',$(this).parent()).removeClass("active");
				
			$('#'+tgId).addClass("active");
			
		});
		
	});
	$(this.getElement).mouseover(this.delegate(this,this.bdStop));
	$(this.getElement).mouseleave(this.delegate(this, this.mouseLeave));
	//최초 메뉴 활성화 실행 
	this.bdStop();
	this.bdTimer = setTimeout(this.name + ".mnbFocus()", 100);	
	
}

GnbObj.prototype.mnbFocus = function(){
	if ( this.bdTimer == null ) { return false;}
	//console.log ("mnbFocus", _mnbSelectId)
	
	$('>li',this.getElement).removeClass("active");
	if (_mnbSelectId[0] != -1){
		$('#gnb_'+_mnbSelectId[0]).addClass("active");
	}
	if ( _mnbSelectId[1] != -1 ){
		$('#gnb_'+_mnbSelectId[0]+'_'+_mnbSelectId[1]).addClass("active");
	}
}

GnbObj.prototype.mouseLeave = function(e){
	/* console.log ( "@@@ mouseLeave ") */
	this.bdStop();
	this.bdTimer = setTimeout(this.name + ".mnbFocus()", 1000);	
}
GnbObj.prototype.bdStop = function(){ clearTimeout(this.bdTimer); this.bdTimer=null; }
GnbObj.prototype.delegate = function(target,func){return function(e){return func.call(target,e);}}
	