/*
 * 파일명:		common.func.js
 * 설  명 :		페이지내 공통 실행필요한 함수 include 
 * 작성자:		glim
 * 최초작성일:	2018/01/23
 * 최종수정일:	2018/04/27
 * Comment
 * 임시 함수파일입니다.
 * 전페이지 공통 실행필요한 함수
 * 20180320 (다국어 dropmenu로 변경, 파일찾기 add)
 * 20180330 scrollplugin 초기화함수추가
 * 20180411 listFoldOnoff 함수추가 (시스템설정 > 자산관리 - 카테고리선택레이어팝업)
 * 20180416 util 공통 추가
 * 20180427 datepicker 추가
 * 20180427 scroll defualt style 변경
*/
 
/* S:20180327 add textarea scroll */
(function($){	
	$(window).on("load",function(){
		
		try {
			var textareaLineHeight=parseInt($(".textarea-wrapper textarea").css("line-height"));
		
			$("div.textarea-wrapper").mCustomScrollbar({
				scrollButtons:{enable:true},// 삭제 20180427
				//theme:"3d-thick",// 삭제 20180427
				scrollInertia:0,
				advanced:{autoScrollOnFocus:false},
				mouseWheel:{disableOver:["select","option","keygen","datalist",""]},
				keyboard:{enable:false},
				snapAmount:textareaLineHeight
			});
						
			
			var textareaWrap = $(".textarea-wrapper");
			$(textareaWrap).each(function(n){
				var textarea=$("textarea", $(this)),
				textareaWrapper=$(this),
				textareaClone=$(".textarea-clone", $(this));
				
				textarea.bind("keyup keydown",function(e){
					var $this=$(this),
					textareaContent=$this.val(),
					clength=textareaContent.length,
					cursorPosition=$this.getCursorPosition();
					textareaContent="<span>"+textareaContent.substr(0,cursorPosition)+"</span>"+textareaContent.substr(cursorPosition,textareaContent.length);
					textareaContent=textareaContent.replace(/\n/g,"<br />");
					textareaClone.html(textareaContent+"<br />");
					$this.css("height",textareaClone.height());
					var textareaCloneSpan=textareaClone.children("span"),textareaCloneSpanOffset=0,
						viewLimitBottom=(parseInt(textareaClone.css("min-height")))-textareaCloneSpanOffset,viewLimitTop=textareaCloneSpanOffset,
						viewRatio=Math.round(textareaCloneSpan.height()+textareaWrapper.find(".mCSB_container").position().top);
					if(viewRatio>viewLimitBottom || viewRatio<viewLimitTop){
						if((textareaCloneSpan.height()-textareaCloneSpanOffset)>0){
							textareaWrapper.mCustomScrollbar("scrollTo",textareaCloneSpan.height()-textareaCloneSpanOffset-textareaLineHeight);
						}else{
							textareaWrapper.mCustomScrollbar("scrollTo","top");
						}
					}
				});
				
				$.fn.getCursorPosition=function(){
					var el=textarea.get(0),pos=0;
					if("selectionStart" in el){
						pos=el.selectionStart;
					}else if("selection" in document){
						el.focus();
						var sel=document.selection.createRange(),selLength=document.selection.createRange().text.length;
						sel.moveStart("character",-el.value.length);
						pos=sel.text.length-selLength;
					}
					return pos;
				}
			});
			
		}
		catch(exception){
			//catchStatements
		}
		
		
	});
})(jQuery);
/* E:20180327 add textarea scroll */ 
 
//$(window).on("load", function (e) {
$(document).ready( function(){

	// 뒤로가기 막기
	// history.pushState(null, null, location.href);
	// window.onpopstate = function (event) {
	// 	history.go(1);
	// };
 
	//jquery datepicker 실행함수 20180427 
	if ( $("[data-role=datepicker]").length > 0 ){
		$("[data-role=datepicker]").datepicker();
	} 
	
	// select 실행 20180208
	if ( $('.ui-sel').length > 0 ){
		$('.ui-sel').each(function(){
			$(this).selectric();//초기화
		});
		
		/* 20180405 add layerpopup 내 selectbox scroll plugin add */
		if ( $(".popup_layer .selectric-sel_white .selectric-scroll").length > 0 ){
			$('.popup_layer .selectric-sel_white').each(function(){
				var a = $(this);
				a.css({'max-height':'200px'});
				$(".selectric-scroll", a).mCustomScrollbar({
					scrollButtons:{enable:true},
					//theme:"3d-thick", //삭제 20180427
				});
				$(".mCSB_scrollTools_vertical", a).off('click').on('click', function(e){
					/* 20180405
					selectric 에 스크롤 plugin 실행시 적용되나 
					스크롤 이동시 selectric 이 off 되므로 강제로 스크롤 클릭시 event 끊어버림
					추후 오류 등 알수없는 버그 발생시 스크롤을 제거해야될거같음.
					*/
					e.preventDefault();
					e.stopPropagation();
				});
			});
			
		}
	}
	
	
	//tooltip init 20180315
	//$( document ).tooltip();
	
	//파일찾기 form 20180319
	if ( $(".file-upload").length > 0 ){
		
		var fileTarget = $('.file-upload'); 
		$(fileTarget).each(function(){
			var a = $(this).find('.file-hidden');
			$(a).on('change', function(){ // 값이 변경되면 
				if(window.FileReader){ // modern browser 
					var filename = $(this)[0].files[0].name;
				}else { // old IE 
					var filename = $(this).val().split('/').pop().split('\\').pop(); // 파일명만 추출 
				} // 추출한 파일명 삽입 
				$(this).siblings('.file-name').val(filename); 
			});
			
		});
	}
	
	//layerpopup scroll plugin
	try {
		$(".mCustomScrollbar").mCustomScrollbar({
			scrollInertia:0,//no used animation
			scrollButtons:{enable:true}, // 삭제 20180427
			//theme:"3d-thick", //삭제 20180427
			callbacks:{
				whileScrolling:function(){
					if (  $('.btn-context-menu-right').length > 0) {
						//windowclose 는 발생시 체크하지만 plugin scroll은 noncheck 20180409
						$('.btn-context-menu-right').contextMenu('close');
					}
				}
			}
		});
	}
	catch(exception){
		//catchStatements
	}
	
	//spinner 실행 20180410
	if ( $('.number-counter > .ip-spinner').length > 0 ){
		$('.number-counter > .ip-spinner').each(function(){
			$('.number-counter > .ip-spinner').spinner({alignment: 'horizontal', min: 1});
		});
	}
		
});

$(function() {

	$(document).click(function(e){
		//다국어 변경 dropmenu 열려있을때 focus 잃으면 off 20180319 add
		if ( !$(e.target).hasClass('btn-open')  ){
			funcLangsDropMenuClose();
		}
		
		//search > 자주사용하는검색, 보기 floating_box 열려있을때 focus 잃으면 off 20180403 add
		if ( !$(e.target).parents().hasClass('floating-list-box')){
			floatingListoff('.floating-list-box');
		}
		
		//utilitem 이 아닐때 focus 잃으면 off 20180416 add
		if ( !$(e.target).parents().hasClass('util-item')  ){
			funcUtilDropBoxClose();
		}
		
	});
	
	
});

/*
* date : 20180416
* last : 20180416
* name : funcUtilDropBox 
* pram : el (click target)
* Desc : util 공통
*/ 
function funcUtilDropBox(el, child){
	var el = $(el);
	$(el).parent().siblings(child).removeClass('on');
	$(el).parent().toggleClass('on');
}
 
/*
* date : 20180416
* last : 20180416 
* name : funcUtilDropBoxClose 
* Desc : util 공통 강제 Close
*/ 
function funcUtilDropBoxClose(){
	$('.util-item').removeClass('on');
}


/*
 * date : 20180220
 * last : 201800313 (다중사용으로 selector 변경)
 * name : tabsOnOff( 선택자, 상위 선택자, 보여지는 컨텐츠 선택자, 콜백함수 )
 * pram :  el (target) / container (parent) / tg (target ele selector)
 * 최상위 container "tab-wrap" << 은 명칭 변경가능
 * tabsOnOff($(this), $(this).parents('.tab-wrap-pop')); 
 */
function tabsOnOff (el, container, callback) {
	var tabitem = $(container).find(el).parents('.tab-item');
	var tg = $($(tabitem).find('.tab-link').attr("href"));//target container
	if ( $(tabitem).hasClass ("on") ){//클릭된타겟 활성화일경우 return
		return false;
	}
	//off
	var oldTabitem = $(container).children().children('.tabs').find('.tab-item.on');//자식노드 20180227
	if ( oldTabitem.length > 0 ){
		//기존 활성화탭 off
		$(oldTabitem).removeClass('on');
		$($(oldTabitem).find('.tab-link').attr("href")).hide();
	}
	
	//on
	tabitem.addClass('on');//tab active
	$(tg).show(0, function(){//tab show
		if ( callback != null && typeof callback === "function" ){
			callback.apply ( null, []);
		}
	});
	return false;
}


/*
 * date : 20180220
 * last : 201800320 (다중사용으로 selector 변경)
 * name : lnbMenuOnoff( 선택자, 상위 선택자, 보여지는 컨텐츠 선택자, 콜백함수 )
 * pram :  el (target) / container (parent) / tg (target ele selector)
 * lnbMenuOnoff($(this), $(this).parents('.lnb-menu'));
 * 20180320 메뉴 활성화 상태와 open 상대 분리
 * 20180426 4depth add 동일사용 - 함수변경
 */
function lnbMenuOnoff (el, container, callback) {
	var item = $(el).parent('li');

	if ( $(item).hasClass ("open") ){
		$(item).removeClass('open');
	}else{
		$(item).addClass('open');
	}
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}

/*
* date : 20180319
* last : 20180319 
* name : funcLangsDropMenu 
* Desc : 다국어 dropmenu toggle
*/ 
function funcLangsDropMenu(){
	$('.dropbox-menu').toggleClass('on');
}


/*
* date : 20180319
* last : 20180319 
* name : funcLangsDropMenuClose 
* Desc : 다국어 dropmenu 강제 close
*/ 
function funcLangsDropMenuClose(){
	$('.dropbox-menu').removeClass('on');
}


/*
* date : 20180319
* last : 20180319 
* name : funcLangsDropMenuChange 
* Desc : 다국어 dropmenu 변경시
*/ 
function funcLangsDropMenuChange(tg){
	var val = $(tg).text();
	$('.dropbox-menu .btn-open').text(val);
	$('.dropbox-menu .menu_list li').removeClass('active');
	$(tg).parent().addClass('active');
	funcLangsDropMenuClose();
}



/*
 * date : 20180319
 * last : 201800319
 * name : floatingConfigOnoff( 선택자, 상위 선택자, 보여지는 컨텐츠 선택자, 콜백함수 )
 * pram :  el (target) / container (parent) / tg (target ele selector) 
 * floatingConfigOnoff($(this), $(this).parents('seletor'));
 * 공통 사용되는지 playbook 에서만 사용인지 확인필요
 */
function floatingConfigOnoff (el, container, callback) {
	var tg = $(container);
	if ( $(tg).hasClass ("on") ){
		$(tg).removeClass('on');
	}else{
		$(tg).addClass('on');
	}
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}

/*
* date : 20180319
* last : 20180319 
* name : floatingConfigoff 
* Desc : flotingConfigPop 강제 close
* pram : container (parent)
*/ 
function floatingConfigoff(container){
	var tg = $(container);
	$(tg).removeClass('on');
}



/*
 * date : 20180319
 * last : 20180403
 * name : floatingConfigOnoff( 선택자, 상위 선택자, 보여지는 컨텐츠 선택자, 콜백함수 )
 * pram :  el (target) / container (parent) / tg (target ele selector) 
 * floatingConfigOnoff($(this), $(this).parents('seletor'));
 * 공통 사용되는지 search 에서만 사용인지 확인필요
 */
function floatingListOnoff (el, container, callback) {
	var tg = $(container);
	if ( $(tg).hasClass ("on") ){
		$(tg).removeClass('on');
	}else{
		$('.floating-list-box').removeClass('on');
		$(tg).addClass('on');
	}
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}

/*
* date : 20180319
* last : 20180319 
* name : floatingConfigoff 
* Desc : flotingConfigPop 강제 close
* pram : container (parent)
*/ 
function floatingListoff(container){
	var tg = $(container);
	$(tg).removeClass('on');
}


/*
 * date : 20180411
 * last : 20180411
 * name : listFoldOnoff( 선택자, 상위 선택자, 보여지는 컨텐츠 선택자, 콜백함수 )
 * pram : el (target) / container (parent selector) / callback
 * listFoldOnoff($(this),'.subject');
	<div class="list_header list-header open">
		<a href="javascript:;" class="subject" onclick="javascript:listFoldOnoff($(this),'.list-header');">System</a>
	</div>
	<div class="list_con list-cont">
		컨텐츠
	</div>
 * used : 시스템설정 > 자산관리 > 카테고리선택 (/admin_05_assets/sts_210.html)
 */
function listFoldOnoff (el, selector, callback) {
	var tg = $(el).parents(selector);
	if ( $(tg).hasClass ("open") ){
		$(tg).next('.list-cont').hide();//.removeClass('open');
		$(tg).removeClass('open');
	}else{
		$(tg).addClass('open');
		$(tg).next('.list-cont').show();
	}
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}

/*
 * date : 20180322
 * last : 20180322
 * name : tblFoldOnoff( 선택자, 상위 선택자, 보여지는 컨텐츠 선택자, 콜백함수 )
 * pram : el (target) / container (parent selector) / callback
 * tblFoldOnoff($(this),'.subject');
 */
function tblFoldOnoff (el, selector, callback) {
	var tg = $(el).parents(selector);
	if ( $(tg).hasClass ("open") ){
		$(tg).next('.sub-cont').hide();//.removeClass('open');
		$(tg).removeClass('open');
	}else{
		$(tg).addClass('open');
		$(tg).next('.sub-cont').show();
	}
	
	if ( callback != null && typeof callback === "function" ){
		callback.apply ( null, []);
	}
	return false;
}

function byteCheck(el){
    var codeByte = 0;
    for (var idx = 0; idx < el.length; idx++) {
        var oneChar = escape(el.charAt(idx));
        if ( oneChar.length == 1 ) {
            codeByte ++;
        } else if (oneChar.indexOf("%u") != -1) {
            codeByte += 2;
        } else if (oneChar.indexOf("%") != -1) {
            codeByte ++;
        }
    }
    return codeByte;
}

function cutByLen(str, maxByte) {
	for (b = i = 0; c = str.charCodeAt(i);) {
		b += c >> 7 ? 2 : 1;
		if (b > maxByte)
			break;
		i++;
	}
	return str.substring(0, i);
}

/*
* date : 20180322
* last : 20180322 
* name : funcTreemapToggle( 선택자, 상위 선택자 )
* pram : tg (target) / selector (parent selector) 
해당 데이터가 없습니다.
*/
function funcTreemapToggle (tg, selector) {
	var tg = $(tg).closest(selector); //li
	var bico = tg.find("i"); // icon
	
	if( tg.hasClass('hide') == true ){ //트리맵 아이콘 - 열어라
		tg.removeClass('hide');
		bico.find('.offscreen').text('닫기');
	}else{// -- 닫아라
		tg.addClass('hide');
		bico.find('.offscreen').text('더보기'); 
	}
}

Date.prototype.format = function(f){
    if(!this.valueOf()) return;
    var weekKorName = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"];
    var weekKorShortName = ["일", "월", "화", "수", "목", "금", "토"];
    var weekEngName = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    var weekEngShortName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var d = this;

    return f.replace(/(yyyy|yy|MM|dd|KS|KL|ES|EL|HH|hh|mm|ss|a\/p)/gi, function ($1) {
        switch ($1) {
            case "yyyy": return d.getFullYear(); // 년 (4자리)
            case "yy": return (d.getFullYear() % 1000).zf(2); // 년 (2자리)
            case "MM": return (d.getMonth() + 1).zf(2); // 월 (2자리)
            case "dd": return d.getDate().zf(2); // 일 (2자리)
            case "KS": return weekKorShortName[d.getDay()]; // 요일 (짧은 한글)
            case "KL": return weekKorName[d.getDay()]; // 요일 (긴 한글)
            case "ES": return weekEngShortName[d.getDay()]; // 요일 (짧은 영어)
            case "EL": return weekEngName[d.getDay()]; // 요일 (긴 영어)
            case "HH": return d.getHours().zf(2); // 시간 (24시간 기준, 2자리)
            case "hh": return ((h = d.getHours() % 12) ? h : 12).zf(2); // 시간 (12시간 기준, 2자리)
            case "mm": return d.getMinutes().zf(2); // 분 (2자리)
            case "ss": return d.getSeconds().zf(2); // 초 (2자리)
            case "a/p": return d.getHours() < 12 ? "오전" : "오후"; // 오전/오후 구분
            default: return $1;
        }
    });
};

String.prototype.string = function (len) { var s = '', i = 0; while (i++ < len) { s += this; } return s; };
String.prototype.zf = function (len) { return "0".string(len - this.length) + this; };
Number.prototype.zf = function (len) { return this.toString().zf(len); };

function getTimezoneName() {
	tmSummer = new Date(Date.UTC(2005, 6, 30, 0, 0, 0, 0));
	so = -1 * tmSummer.getTimezoneOffset();
	tmWinter = new Date(Date.UTC(2005, 12, 30, 0, 0, 0, 0));
	wo = -1 * tmWinter.getTimezoneOffset();
    if (-660 == so && -660 == wo) return 'Pacific/Midway';
    if (-600 == so && -600 == wo) return 'Pacific/Tahiti';
    if (-570 == so && -570 == wo) return 'Pacific/Marquesas';
    if (-540 == so && -600 == wo) return 'America/Adak';
    if (-540 == so && -540 == wo) return 'Pacific/Gambier';
    if (-480 == so && -540 == wo) return 'US/Alaska';
    if (-480 == so && -480 == wo) return 'Pacific/Pitcairn';
    if (-420 == so && -480 == wo) return 'US/Pacific';
    if (-420 == so && -420 == wo) return 'US/Arizona';
    if (-360 == so && -420 == wo) return 'US/Mountain';
    if (-360 == so && -360 == wo) return 'America/Guatemala';
    if (-360 == so && -300 == wo) return 'Pacific/Easter';
    if (-300 == so && -360 == wo) return 'US/Central';
    if (-300 == so && -300 == wo) return 'America/Bogota';
    if (-240 == so && -300 == wo) return 'US/Eastern';
    if (-240 == so && -240 == wo) return 'America/Caracas';
    if (-240 == so && -180 == wo) return 'America/Santiago';
    if (-180 == so && -240 == wo) return 'Canada/Atlantic';
    if (-180 == so && -180 == wo) return 'America/Montevideo';
    if (-180 == so && -120 == wo) return 'America/Sao_Paulo';
    if (-150 == so && -210 == wo) return 'America/St_Johns';
    if (-120 == so && -180 == wo) return 'America/Godthab';
    if (-120 == so && -120 == wo) return 'America/Noronha';
    if (-60 == so && -60 == wo) return 'Atlantic/Cape_Verde';
    if (0 == so && -60 == wo) return 'Atlantic/Azores';
    if (0 == so && 0 == wo) return 'Africa/Casablanca';
    if (60 == so && 0 == wo) return 'Europe/London';
    if (60 == so && 60 == wo) return 'Africa/Algiers';
    if (60 == so && 120 == wo) return 'Africa/Windhoek';
    if (120 == so && 60 == wo) return 'Europe/Amsterdam';
    if (120 == so && 120 == wo) return 'Africa/Harare';
    if (180 == so && 120 == wo) return 'Europe/Athens';
    if (180 == so && 180 == wo) return 'Africa/Nairobi';
    if (240 == so && 180 == wo) return 'Europe/Moscow';
    if (240 == so && 240 == wo) return 'Asia/Dubai';
    if (270 == so && 210 == wo) return 'Asia/Tehran';
    if (270 == so && 270 == wo) return 'Asia/Kabul';
    if (300 == so && 240 == wo) return 'Asia/Baku';
    if (300 == so && 300 == wo) return 'Asia/Karachi';
    if (330 == so && 330 == wo) return 'Asia/Calcutta';
    if (345 == so && 345 == wo) return 'Asia/Katmandu';
    if (360 == so && 300 == wo) return 'Asia/Yekaterinburg';
    if (360 == so && 360 == wo) return 'Asia/Colombo';
    if (390 == so && 390 == wo) return 'Asia/Rangoon';
    if (420 == so && 360 == wo) return 'Asia/Almaty';
    if (420 == so && 420 == wo) return 'Asia/Bangkok';
    if (480 == so && 420 == wo) return 'Asia/Krasnoyarsk';
    if (480 == so && 480 == wo) return 'Australia/Perth';
    if (540 == so && 480 == wo) return 'Asia/Irkutsk';
    if (540 == so && 540 == wo) return 'Asia/Seoul';
    if (570 == so && 570 == wo) return 'Australia/Darwin';
    if (570 == so && 630 == wo) return 'Australia/Adelaide';
    if (600 == so && 540 == wo) return 'Asia/Yakutsk';
    if (600 == so && 600 == wo) return 'Australia/Brisbane';
    if (600 == so && 660 == wo) return 'Australia/Sydney';
    if (630 == so && 660 == wo) return 'Australia/Lord_Howe';
    if (660 == so && 600 == wo) return 'Asia/Vladivostok';
    if (660 == so && 660 == wo) return 'Pacific/Guadalcanal';
    if (690 == so && 690 == wo) return 'Pacific/Norfolk';
    if (720 == so && 660 == wo) return 'Asia/Magadan';
    if (720 == so && 720 == wo) return 'Pacific/Fiji';
    if (720 == so && 780 == wo) return 'Pacific/Auckland';
    if (765 == so && 825 == wo) return 'Pacific/Chatham';
    if (780 == so && 780 == wo) return 'Pacific/Enderbury';
    if (840 == so && 840 == wo) return 'Pacific/Kiritimati';
	return 'US/Pacific';
}

// cookie life cycle
var Cookie =
{
    cookie_arr : null,
 
    set : function (name,value,options)
    {
        options = options || {};
 
        this.cookie_arr = [escape(name) + '=' + escape(value)];
 
        //-- expires
        if (options.expires)
        {
            if( typeof options.expires === 'object' && options.expires instanceof Date )
            {
                var date = options.expires;
                var expires = "expires=" + date.toUTCString();
                this.cookie_arr.push (expires);
            }
        }
        else if (options.expires_day)
        {
            this.set_expires_date (options.expires_day , 24*60*60);
        }
        else if (options.expires_hour)
        {
            this.set_expires_date (options.expires_hour , 60*60);
        }
 
        //-- domain
        if (options.domain)
        {
            var domain = "domain=" + options.domain;
            this.cookie_arr.push (domain);
        }
 
        //-- path
        if (options.path)
        {
            var path = 'path=' + options.path;
            this.cookie_arr.push (path);
        }
 
        //-- secure
        if( options.secure === true )
        {
            var secure = 'secure';
            this.cookie_arr.push (secure);
        }
 
        document.cookie = this.cookie_arr.join('; ');
    },
 
    get : function (name)
    {
        var nameEQ = escape(name) + "=";
        var ca = document.cookie.split(';');
 
        for(var i=0;i < ca.length;i++)
        {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1,c.length);
            if (c.indexOf(nameEQ) == 0) return unescape(c.substring(nameEQ.length,c.length));
        }
        return null;
    },
 
    del : function (name , options)
    {
        options = options || {};
        options.expires_day = -1;
        this.set ( name , '' , options );
    },
    set_expires_date : function (expires , time)
    {
        var date = new Date();
        date.setTime(date.getTime()+(expires*time*1000));
        expires = "expires=" + date.toUTCString();
        this.cookie_arr.push (expires);
        
    }
};

// localStorate life cycle
var storage = {
    _key: '',
    _value : '',
    set : function(key, value){
        this._key = key;
        this._value = value;
        if(!Cookie.get('expiration_timestamp')){
            return null;
        }
        return localStorage.setItem(key, JSON.stringify(this._value));
    },
    get : function(key){
        var item = JSON.parse(localStorage.getItem(key));
        if(!Cookie.get('expiration_timestamp')){
            this.del();
            return null;
        }
        return item;
    },
    del : function(){
        return localStorage.clear();
    }
};

function pop_open(compName,params,name){

	let query = new URLSearchParams(window.location.search);
	const mid = query.get('mId');
	var path = "/WinPopup?mId="+mid+"&comp="+compName+"&"+params;
	var options;
	
	switch(compName){
		case 'AdminAnomalyRule':
		case 'AdminAlarmRule':
			options = "width=950, height=709, toolbar=no, scrollbars=no, resizable=no, left=10, top=10";
			break;
		case 'AssetView':
			options = "width=1380, height=830, toolbar=no, scrollbars=no, resizable=no, left=10, top=10";
			break;
		case 'Cases':
            options = "width=1875, height=799, toolbar=no, scrollbars=no, resizable=no, left=10, top=10";
			break;
		case 'ResponsesAll': // skinfo_1364 일괄처리를 위한 팝업 추가
			options = "width=1875, height=880, toolbar=no, scrollbars=no, resizable=no, left=10, top=10";
			break;
		case 'AdminAnalysisRule':
		case 'AdminAnalysisRuleNew':
            options = "width=1880, height=862, toolbar=no, scrollbars=no, resizable=no, left=10, top=10";
			break;
		case 'Responses':
		case 'Alarms':
			options = "width=1875, height=923, toolbar=no, scrollbars=no, resizable=no, left=10, top=10";
			break;
	}
	
	//window.open(path,name,options);
	window.open(path,"_blank",options);
};

String.prototype.initCap = function(){
	var str = this.substring(0, 1).toUpperCase() + this.substring(1, this.length).toLowerCase();
	return str;
};

/*
* date : 20200318
* name : addScrollEvent( 선택자 )
* pram : el (selector)
* comm : React Dom 생성시 간헐적으로 스크롤 생성을 못하는 현상이 발생함.
*        해당 함수로 React life cycle에 반영을 하기 위함.
*/
function addScrollEvent(el){
    $(el).mCustomScrollbar({
        scrollInertia:0,//no used animation
        scrollButtons:{enable:true}, // 삭제 20180427
    });
}