/*
 * 파일명:		tag.control.js
 * 설명:		header 공통 filter 슬라이드 스크립트
 * 작성자:		glim
 * 최초작성일:	2018/02/20
 * 최종수정일:	2018/03/13 (bug update)
 Filter 목록 슬라이더
(2/19 이전산출물중 filter Markup 은 변경필요)
- 수정대상 (insider_trareat/alarm_monitoring/detection_response) 2/20 수정전달
1. 마크업 구조 맞춰야함
2. tag-list 여러개 가능 (단 각 선택자는 있어야함)
3. 목록이 적을때는 컨트롤러 숨김처리
4. 다중처리로 인해 selector 변경 (20180313)
 */


//$(function () {
$(document).ready( function(){
	if ($(".tag-list").length > 0) {
		/* font load 이슈로 last target 여백이 많이 남는경우있음..
		그래서 settimeout 처리함
		20180313 update: 보여지는 tag list 만 처리
		*/
		setTimeout(function(){ 
			$(".tag-list:visible").each(function(n) {
				funcSetTagList($(this));
			});
		}, 1000);
		// 필터 업데이트시 'funcSetTagList(태그 리스트 jQuery Object)' 실행
	}
});

//Tag List (element)
function funcSetTagList(target) {
	var wrapper, tagWrapper, viewWidth, maskWidth, tagTotalWidth, tagList, currentIndex, tagTotalCnt, currentTranslateX;
	wrapper = $(target);						// 태그 리스트
	tagWrapper = wrapper.find(".mask");		// 각 tag wrapper 
	viewWidth = wrapper.width();			// 보여지는 넓이
	maskWidth = 0;							// 마스크([...])영역 사이즈
	tagTotalWidth = 0;						// 태그 전체에 대한 넓이값
	currentIndex = 0;						// 현재 제일 좌측에 보이는 태그의 index
	currentTranslateX = 0;					// 현재 좌우 translate된 x 값
	tagList = wrapper.find(".tag");			// 태그 전체 Array
	tagTotalCnt = tagList.length;			// 태그 갯수
	
	//tag-list	
	tagList.each(function(m) {//태그목록들 전체 넓이
		var that = $(this);
		tagTotalWidth += that.outerWidth(true);
	});
	tagTotalWidth = Math.ceil(tagTotalWidth);//ie11 떨어져서 무조건 반올림
	tagWrapper.css({ "left" : 0 });

	// 태그 넓이값 합산이 리스트 영역 넓이값보다 큰 경우
	if (viewWidth < tagTotalWidth) {
		// s: 기본 셋팅
		wrapper.find("> .control-wrap.btns").addClass('on');//.css('opacity',1);
		tagWrapper.css({"width": Math.max(viewWidth, tagTotalWidth),"left":0});

		// 초기 currentIndex가 0이므로 좌측 마스크 숨김
		wrapper.find("> .control-wrap.before").removeClass('on');//.css('opacity', 0);
		wrapper.find("> .control-wrap.btns").find(".btn-tag-prev").addClass('disabled');
		wrapper.find("> .control-wrap.after").addClass('on');//.css('opacity', 1);
		wrapper.find("> .control-wrap.btns").find(".btn-tag-next").removeClass('disabled');
		// e: 기본 셋팅

		// 이전 버튼 클릭 이벤트
		wrapper.find("> .control-wrap.btns .btn-tag-prev").off("click").on("click", function(event) {
			if (currentIndex > 0) {
				//console.log ( "currentIndex", currentIndex)
				var idx=currentIndex - 1;
				if ( idx===0){ currentTranslateX = 0; }
				else{ 
					currentTranslateX = tagList.eq(idx).position().left;
				}
				tagWrapper.css({
					"left" : -currentTranslateX
				});
				currentIndex--;
				// 현재 태그 index가 0이 된 경우 좌측 마스크 숨김
				if (currentIndex === 0) {
					wrapper.find("> .control-wrap.before").removeClass('on');//.css('opacity', 0);
					wrapper.find("> .control-wrap.btns").find(".btn-tag-prev").addClass('disabled');
				}
			}else{
				tagWrapper.css({
					"left" : 0
				});
				wrapper.find("> .control-wrap.before").removeClass('on');//.css('opacity', 0);
				wrapper.find("> .control-wrap.btns").find(".btn-tag-prev").addClass('disabled');
			}
			// 우측 마스크 노출
			wrapper.find("> .control-wrap.after").addClass('on');//.css('opacity', 1)
			wrapper.find("> .control-wrap.btns").find(".btn-tag-next").removeClass('disabled');
		});

		// 다음 버튼 클릭 이벤트
		wrapper.find("> .control-wrap.btns .btn-tag-next").off("click").on("click", function(event) {
			//console.log ("~~ next");
			if(wrapper.find("> .control-wrap.btns").find(".btn-tag-next").hasClass('disabled') == true){return;}
			
			// 좌측 마스크 노출
			//wrapper.find("> .control-wrap.before").show();
			wrapper.find("> .control-wrap.before").addClass('on');//.css('opacity', 1);
			wrapper.find("> .control-wrap.btns").find(".btn-tag-prev").removeClass('disabled');
			
			//console.log ( "###  " , currentIndex , " -- ")
			tagTotalWidth = wrapper.find('.tag-wrap > .mask').width();
			currentTranslateX = tagList.eq(currentIndex).position().left;
			var afterLeft = wrapper.find("> .control-wrap.after").position().left;
			
			var toRightView = Math.round(tagTotalWidth - currentTranslateX - afterLeft);
			var lastTagWidth = Math.round(tagList.eq(tagTotalCnt - 1).outerWidth(true));
			
			//console.log("toRightView = " , toRightView , "lastTagWidth = ", lastTagWidth);
			if ( toRightView > lastTagWidth){ //일반처리				
				currentTranslateX = tagList.eq(currentIndex).position().left + tagList.eq(currentIndex).outerWidth(true);
								
				currentIndex++;
			}else if( toRightView <= lastTagWidth ){//마지막일때
				
				//console.log ( "마지막", viewWidth , tagTotalWidth)
				currentTranslateX = tagTotalWidth - viewWidth ;
				wrapper.find("> .control-wrap.after").removeClass('on');//.css('opacity', 0);
				wrapper.find("> .control-wrap.btns").find(".btn-tag-next").addClass('disabled');
			}
			
			tagWrapper.css({
				"left": -(currentTranslateX - maskWidth)
			});
			/* tagWrapper.css({
				"transform": "translate(-" + (currentTranslateX - maskWidth) + "px, 0)"
			}); */

		});
		
	}
	// 태그 넓이값 합산이 리스트 영역 넓이값보다 작은 경우
	else {
		tagWrapper.width(viewWidth);
		wrapper.find("> .control-wrap").removeClass('on');//.css("opacity", 0);
	}
}