var targetTags = document.querySelectorAll('.tab_item a');
var targetIds = [];


function setTargetOffset(){
    targetIds = [];

    targetTags.forEach(function(target){

        var id = target.href.split('#')[1];
        targetIds.push({
            top: document.getElementById(id).offsetTop,
            id: id
        })
    })
}

function getOffsetTarget(scrollTop){

    var resId;

    if(scrollTop+document.body.clientHeight === document.body.scrollHeight){
        resId = targetIds[targetIds.length - 1].id;
    } else {
        targetIds.forEach(function(id){
            if(resId === undefined && scrollTop <= id.top){
                resId = id.id;
            }
        })
    }
    return resId;
}


document.addEventListener("scroll", scrollEvent);
function scrollEvent(event){
    setTargetOffset();

    var whois = getOffsetTarget(event.target.scrollingElement.scrollTop);

    document.querySelectorAll('.tab_item').forEach(function(tabItem){
        tabItem.classList.remove('on');
    })

    var target = document.querySelector("[href='#"+whois+"']");
    target.parentNode.classList.add('on');
}
