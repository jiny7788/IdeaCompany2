export const userData = [
    {
      name: 'Jan',
      'Active User': 4490,
    },
    {
        name: 'Feb',
        'Active User': 3430,
    },
    {
        name: 'Mar',
        'Active User': 2490,
      },
      {
        name: 'Apr',
        'Active User': 3390,
      },{
        name: 'May',
        'Active User': 1230,
      },{
        name: 'Jun',
        'Active User': 5290,
      },{
        name: 'Jul',
        'Active User': 2390,
      },{
        name: 'Aug',
        'Active User': 4540,
      },{
        name: 'Sep',
        'Active User': 4235,
      },{
        name: 'Oct',
        'Active User': 4490,
      },{
        name: 'Nov',
        'Active User': 4500,
      },{
        name: 'Dec',
        'Active User': 4600,
      }
  ];
